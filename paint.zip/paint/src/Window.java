import paint.DrawPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JMenuBar;


public class Window extends JFrame {
    ButtonPanel bp;
    DrawPanel rp;
	
	public Window () throws IOException {
		// �super � calls a function inherited from the parent class ( JFrame )
		super ();
                Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setTitle (" Callbacks ");
		setSize (new Dimension ((screen.width - 300), screen.height ));
		// Make sure the window appears in the middle of your screen
		setLocationRelativeTo ( null );
		// Determines what should happen when the frame is closed
		setDefaultCloseOperation ( EXIT_ON_CLOSE );
		// Chooses a certain layout type for the elements in this frame
		getContentPane (). setLayout (new BorderLayout ());
		 rp = new DrawPanel (this);
		 bp = new ButtonPanel (rp,this);
                 JMenuBar menubar = bp.createMenu(rp);
                 this.setJMenuBar(menubar);
		// Places the DrawPanel in the center of the frame
		getContentPane (). add (rp , BorderLayout . CENTER );
		// Places the ButtonPanel in the top of the frame
		getContentPane (). add (bp , BorderLayout . WEST );
                bp.setPreferredSize(new Dimension(200,screen.height));
                
                //getContentPane ().getComponent(1).setBackground(Color.decode("#3E3E3E"));
		setVisible ( true );
		}
       public void updateButtonPanel(DrawPanel dp) throws IOException{
            
            getContentPane().remove(bp);
            getContentPane().remove(rp);
            
                  
            bp = new ButtonPanel(rp,this);
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            
		setTitle (" Callbacks ");
		setSize (new Dimension ((screen.width - 300), screen.height - 50));
		System.out.println("update buttons");
            	
                getContentPane (). setLayout (new BorderLayout ());

            	getContentPane (). add (bp , BorderLayout . WEST );
                getContentPane (). add (rp , BorderLayout . CENTER );
                bp.setPreferredSize(new Dimension(200,screen.height));
                setVisible(true);

        
        
	
}}
