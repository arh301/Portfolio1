
import paint.MyChooserPanel;
import paint.DrawPanel;
import paint.DrawPanel.Tools;
import static paint.DrawPanel.Tools.outline;
import static com.sun.java.accessibility.util.AWTEventMonitor.addActionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ButtonPanel extends JPanel {
    DrawPanel dp;
    Window window; 
    
    public ButtonPanel(DrawPanel dp, Window w) throws IOException {
        
        super();
        
        this.dp = dp;
        window = w;
        createMenu(dp);

        JColorChooser color = new JColorChooser(dp.color);
        AbstractColorChooserPanel[] oldPanels = color.getChooserPanels();
        for (int i = 0; i < oldPanels.length; i++) {
            String clsName = oldPanels[i].getClass().getName();
            if (clsName.equals("javax.swing.colorchooser.DefaultSwatchChooserPanel")) {
                color.removeChooserPanel(oldPanels[i]);
            } else if (clsName.equals("javax.swing.colorchooser.DefaultRGBChooserPanel")) {
                color.removeChooserPanel(oldPanels[i]);
            } else if (clsName.equals("javax.swing.colorchooser.DefaultHSBChooserPanel")) {
                color.removeChooserPanel(oldPanels[i]);
            } else if (clsName.equals("javax.swing.colorchooser.ColorChooserPanel")) {
                color.removeChooserPanel(oldPanels[i]);

            }
        }

  color.addChooserPanel(new MyChooserPanel(dp));
//        color.setBackground(Color.decode("#BFBFBF"));
        color.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.black, 0),
                BorderFactory.createLineBorder(Color.decode("#3E3E3E"), 10)));
        color.setPreviewPanel(new JPanel());

        JPanel figurePanel = new JPanel(new GridLayout(3, 2, 0, 0));

        JPanel figureActionPanel = new JPanel(new GridLayout(4, 1));

        AbstractColorChooserPanel[] chooserPanels;// = color.getChooserPanels();
        JButton fill = new JButton();
        JButton squ = new JButton();
        JButton rec = new JButton();
        JButton cir = new JButton();
        JButton ecl = new JButton();
        JButton lin = new JButton();
        JButton move = new JButton();
        JButton im = new JButton();
        JButton text = new JButton();
        JButton del = new JButton();
        JButton resize = new JButton();
        String location = "images/";

        chooserPanels = color.getChooserPanels();

        squ.setForeground(Color.WHITE);
        squ.setBackground(Color.BLACK);
        squ.setBorderPainted(false);
        squ.setBorder(BorderFactory.createEmptyBorder());
        squ.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "SQ.png")));
        squ.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "SQ1.png")));
        if (dp.tool == Tools.placeSqu) {
            squ.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "SQ1.png")));

        }
        squ.setActionCommand("Squ");
        squ.addActionListener(new InputHandler(dp, squ, w));

        rec.setForeground(Color.WHITE);
        rec.setBackground(Color.BLACK);
        rec.setBorderPainted(false);
        rec.setBorder(BorderFactory.createEmptyBorder());
        rec.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "REC.png")));
        rec.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "REC1.png")));
        if (dp.tool == Tools.placeRec) {
            rec.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "REC1.png")));
        }
        rec.setName("Rec");
        rec.setActionCommand("Rec");
        rec.addActionListener(new InputHandler(dp, rec, w));

        cir.setForeground(Color.WHITE);
        cir.setBackground(Color.BLACK);
        cir.setBorderPainted(false);
        cir.setBorder(BorderFactory.createEmptyBorder());
        cir.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "CIR.png")));
        cir.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "CIR1.png")));
        if (dp.tool == Tools.placeCir) {
            cir.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "CIR1.png")));

        }
        cir.setName("Cir");
        cir.setActionCommand("Cir");
        cir.addActionListener(new InputHandler(dp, cir, w));

        ecl.setForeground(Color.WHITE);
        ecl.setBackground(Color.BLACK);
        ecl.setBorderPainted(false);
        ecl.setBorder(BorderFactory.createEmptyBorder());
        ecl.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "EL.png")));
        ecl.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "EL1.png")));
        if (dp.tool == Tools.placeEll) {
            ecl.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "EL1.png")));
        }
        ecl.setName("Ecl");
        ecl.setActionCommand("Ecl");
        ecl.addActionListener(new InputHandler(dp, ecl, w));

        lin.setForeground(Color.WHITE);
        lin.setBackground(Color.BLACK);
        lin.setBorderPainted(false);
        lin.setBorder(BorderFactory.createEmptyBorder());
        lin.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "line.png")));
        lin.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "line1.png")));
        if (dp.tool == Tools.placeLine) {
            lin.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "line1.png")));

        }
        lin.setName("Line");
        lin.setActionCommand("Line");
        lin.addActionListener(new InputHandler(dp, lin, w));

        move.setForeground(Color.WHITE);
        move.setBackground(Color.BLACK);
        move.setBorderPainted(false);
        move.setBorder(BorderFactory.createEmptyBorder());
        move.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "move.png")));
        move.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "move1.png")));
        if (dp.tool == Tools.move) {
            move.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "move1.png")));
        }
        move.setName("Move");
        move.setActionCommand("Move");
        move.addActionListener(new InputHandler(dp, move, w));

        text.setForeground(Color.WHITE);
        text.setBackground(Color.BLACK);
        text.setBorderPainted(false);
        text.setName("Text");
        text.setBorder(BorderFactory.createEmptyBorder());
        text.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "T.png")));
        text.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "T1.png")));
        if (dp.tool == Tools.text) {
            text.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "T1.png")));
        }
        text.setActionCommand("Text");
        text.addActionListener(new InputHandler(dp, text, w));

        del.setName("Delete");
        del.setForeground(Color.WHITE);
        del.setBackground(Color.BLACK);
        del.setBorderPainted(false);
        del.setBorder(BorderFactory.createEmptyBorder());
        del.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "DELETE.png")));
        del.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "DELETE1.png")));
        if (dp.tool == Tools.delete) {
            del.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "DELETE1.png")));
        }
        del.setActionCommand("Del");
        del.addActionListener(new InputHandler(dp, del, w));

        im.setName("Image");
        im.setForeground(Color.WHITE);
        im.setBackground(Color.BLACK);
        im.setBorderPainted(false);
        im.setBorder(BorderFactory.createEmptyBorder());
        im.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "image.png")));
        im.setActionCommand("Image");
        im.addActionListener(new InputHandler(dp, im, w));

        resize.setForeground(Color.WHITE);
        resize.setBackground(Color.BLACK);
        resize.setBorderPainted(false);
        resize.setName("Resize");
        resize.setBorder(BorderFactory.createEmptyBorder());
        resize.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "RESIZE.png")));
        resize.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "RESIZE1.png")));
        if (dp.tool == Tools.resize) {
            resize.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "RESIZE1.png")));
        }
        resize.setActionCommand("Resize");
        resize.addActionListener(new InputHandler(dp, resize, w));

        figurePanel.add(lin);
        figurePanel.add(text);
        figurePanel.add(squ);
        figurePanel.add(rec);
        figurePanel.add(cir);
        figurePanel.add(ecl);
        add(figurePanel);

        figureActionPanel.add(im);
        figureActionPanel.add(move);
        figureActionPanel.add(resize);
        figureActionPanel.add(del);
        add(figureActionPanel);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 1));

        JButton stroke = new JButton("STROKE COLOR");
        stroke.setBackground(Color.decode("#3E3E3E"));
        stroke.setForeground(Color.decode("#BFBFBF")); //#BFBFBF
        stroke.setFocusable(false);
        stroke.setFont(new Font("Arial", Font.PLAIN, 15));
        stroke.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.black, 10),
                BorderFactory.createLineBorder(Color.decode("#3E3E3E"), 5)));
        stroke.setHorizontalAlignment(SwingConstants.LEFT);
        stroke.setActionCommand("Stroke");
        stroke.addActionListener(new InputHandler(dp, stroke, w));
        panel.add(stroke);

        fill.setForeground(Color.WHITE);
        fill.setBackground(Color.BLACK);
        fill.setBorderPainted(false);
        fill.setBorder(BorderFactory.createEmptyBorder());
        fill.setIcon(new ImageIcon(ButtonPanel.class.getResource(location + "FILL.png")));
        fill.setPressedIcon(new ImageIcon(ButtonPanel.class.getResource(location + "FILL1.png")));
        fill.setName("Fill");
        fill.setActionCommand("Fill");
        fill.addActionListener(new InputHandler(dp, fill, w));
        panel.add(fill);

        setBackground(Color.decode("#3E3E3E"));
        add(panel);

        JPanel bottom = new JPanel();
        bottom.setLayout(new GridLayout(1, 2));

        bottom.add(color);

        JButton button = new JButton("");
        button.setBackground(dp.color);
        button.setMaximumSize(new Dimension(40, 40));
        //button.setFocusable(false);
        //fill.setFocusPainted(false);
        button.setBorder(new LineBorder(Color.BLACK));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.decode("#3E3E3E"), 25),
                BorderFactory.createLineBorder(Color.black, 0)));
        bottom.add(button);
        add(bottom);

//    
        
        color.getSelectionModel().addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent ce) {
                dp.color = color.getColor();
                
                dp.active = null;
                dp.x = 0;
                dp.y = 0;

                dp.tool = dp.lastTool;
                dp.paint();

                
            }
        ;

    }

    );

    }

    public JMenuBar createMenu(DrawPanel dp) {
        JMenuBar menuBar = new JMenuBar();

           
       
        JMenuItem menuItem = new JMenuItem("New",KeyEvent.VK_T);
        menuItem.setActionCommand("New");
        menuItem.setMaximumSize(new Dimension(40,50));
        menuItem.addActionListener(new InputHandler(dp, menuItem, window));
        menuBar.add(menuItem);
        
         menuItem = new JMenuItem("Start",KeyEvent.VK_T);
        menuItem.setActionCommand("Start");
        menuItem.setMaximumSize(new Dimension(40,50));
        menuItem.addActionListener(new InputHandler(dp, menuItem, window));
        menuBar.add(menuItem);
        
         menuItem = new JMenuItem("Stop",KeyEvent.VK_T);
        menuItem.setActionCommand("Stop");
        menuItem.setMaximumSize(new Dimension(40,50));
        menuItem.addActionListener(new InputHandler(dp, menuItem, window));
        menuBar.add(menuItem);

        menuItem = new JMenuItem("Save",KeyEvent.VK_B);
        menuItem.setActionCommand("Save");
        menuItem.setMaximumSize(new Dimension(40,50));
        menuItem.addActionListener(new InputHandler(dp, menuItem, window));
        menuBar.add(menuItem);
        
        return menuBar;

    }
}
