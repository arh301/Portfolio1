
import paint.DrawPanel;
import paint.DrawPanel.Tools;
import paint.MyRectangle;
import paint.StopWatch;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;
import javax.swing.filechooser.FileNameExtensionFilter;

public class InputHandler implements ActionListener {

    public DrawPanel dp;
    ButtonPanel bp;
    public JButton button;
    public Window window;
    public JMenuItem menuItem;

    public InputHandler(DrawPanel dp, JButton b, Window w) {
        this.dp = dp;
        button = b;
        window = w;
    }

    InputHandler(DrawPanel dp, JMenuItem b, Window window) {
        this.dp = dp;
        menuItem = b;
        window = window;
    }

    public void getClickPosition(ActionEvent e) {

    }

    public void actionPerformed(ActionEvent e) {
        //System.out.println(e.getSource().toString()+" in action perfomed");
        if ("Fill".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.fill;
            dp.x = 0;
            dp.y = 0;
            dp.lastTool = Tools.fill;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Stroke".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.outline;
            dp.x = 0;
            dp.y = 0;
            dp.lastTool = Tools.outline;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Image".equals(e.getActionCommand())) {
            dp.clicks++;

            JFileChooser chooser = new JFileChooser();
            chooser.showOpenDialog(null);
            final File f = chooser.getSelectedFile();
            String filename = f.getAbsolutePath();

            if (f == null) {
                return;
            }

            try {
                BufferedImage img = ImageIO.read(new File(f.getAbsolutePath()));
                MyImage image = new MyImage(img);
                dp.shapesList.add(image);
                System.out.println(filename);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            dp.tool = Tools.image;
        }
        if ("Rec".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.placeRec;
            try {
                window.updateButtonPanel(dp);

            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        if ("Cir".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.placeCir;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Squ".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.placeSqu;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if ("Line".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.placeLine;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if ("Ecl".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.placeEll;
            
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Del".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.delete;
            dp.x = 0;
            dp.y = 0;
            for (JTextArea s : dp.textList) {
                s.setEditable(false);
            }
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Image".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.image;
        }
        if ("New".equals(e.getActionCommand())) {

            try {
                new Window();

            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if("Start".equals(e.getActionCommand())){
            dp.sw = new StopWatch();
            
        }
        if("Stop".equals(e.getActionCommand())){
            long time = dp.sw.elapsedTime();
            long minutes = TimeUnit.MILLISECONDS.toMinutes(time);
            long seconds = TimeUnit.MILLISECONDS.toSeconds(time);
            long secs = seconds - (minutes*60);
            System.out.println("Time taken: " + minutes + " min " + seconds + " secs" );
            System.out.println("Steps taken: " + dp.clicks);
            dp.resetClicks();
        }
        
        
        if ("Save".equals(e.getActionCommand())) {

            long time = dp.sw.elapsedTime();
            long minutes = TimeUnit.MILLISECONDS.toMinutes(time);
            long seconds = TimeUnit.MILLISECONDS.toSeconds(time);
            System.out.println("Time taken: " + minutes + " min " + seconds + " secs" );
            System.out.println("Steps taken: " + dp.clicks);

            
            
            
            BufferedImage bImg = new BufferedImage(dp.getWidth(), dp.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D cg = bImg.createGraphics();

            dp.paintAll(cg);
            JFileChooser filechooser = new JFileChooser();
//      FileNameExtensionFilter filter = new FileNameExtensionFilter(
//               "PNG images", "PNG");
//      filechooser.setFileFilter(filter);
            int result = filechooser.showSaveDialog(dp);
            if (result == JFileChooser.APPROVE_OPTION) {
                File saveFile = filechooser.getSelectedFile();
                try {
                    ImageIO.write(bImg, "png", saveFile);

                } catch (IOException p) {
                    p.printStackTrace();
                }
            }
        }
        if ("Move".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.move;
            dp.active = null;
            dp.x = 0;
            dp.y = 0;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if ("Text".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.text;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        if ("Resize".equals(e.getActionCommand())) {
            dp.clicks++;
            dp.tool = Tools.resize;
            dp.active = null;
            dp.x = 0;
            dp.y = 0;
            try {
                window.updateButtonPanel(dp);
            } catch (IOException ex) {
                Logger.getLogger(InputHandler.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
