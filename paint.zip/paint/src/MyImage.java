
import paint.DrawPanel;
import paint.Drawable;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anna
 */
public class MyImage  implements Drawable {

 private double x1, y1, x2, y2;
 public Image img;
 
    MyImage(BufferedImage img) {
        this.img = img;
        double width = img.getWidth();
        double height = img.getHeight();
        if(width >= 800 || height >= 800){
            width = width*0.6;
            height = height*0.6;
        }
        x1 = 100;
        x2 = x1 + width;
        System.out.println(x2);
        y1 = 100;
        y2 = y1 + height;
  
        
    }

    @Override
    public void draw(Graphics2D g) {
        double x = getStartX();
        double y = getStartY();
        double width = getWidth();
        double height = getHeight();
        g.drawImage(img, (int)x, (int)y, (int)width, (int)height, null);
        
        g.draw(new Rectangle2D.Double(x, y, width, height));
        
    }

    private double getStartX() {
        return Math.min(x1, x2);
    }

    private double getStartY() {
        return Math.min(y1, y2);
    }

    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if (getStartX() <= xcheck && xcheck <= getStartX() + getWidth() && getStartY() <= ycheck && ycheck <= getStartY() + getHeight()) {
            contains = true;
            return contains;
        } else {
            return contains;
        }
    }

     @Override
    public double getX() {
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }

    @Override
    public double getWidth() {
        return Math.abs(x2 - x1);
    }

    @Override
    public double getHeight() {
        return Math.abs(y2 - y1);
    }

    @Override
    public void setColor(Color color) {
    }

    @Override
    public Color getColor() {
        return null;
    }

    @Override
    public void setFill(Color fill) {
       }

    @Override
    public String getShape() {
        return "image";
    }
@Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

    
   
    
}
