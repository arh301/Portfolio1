import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;


public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		SwingUtilities . invokeLater (new Runnable () {
			public void run () {
                            try {
                                new Window ();
                            } catch (IOException ex) {
                                Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
                            }
			}
			});
	}

}
