/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import java.util.concurrent.TimeUnit;
import static javafx.util.Duration.millis;

/**
 *
 * @author Anna
 */
public class StopWatch {
    public final long before;

    public StopWatch() {
        before = System.currentTimeMillis();
       
    }

    public long elapsedTime() {
        long after = System.currentTimeMillis();
       
        return after - before;
   }
}
