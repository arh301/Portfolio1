package paint;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import javax.swing.colorchooser.AbstractColorChooserPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anna
 */
public class MyChooserPanel extends AbstractColorChooserPanel {
    DrawPanel dp;
            
    public  MyChooserPanel(DrawPanel dp){
        this.dp = dp;
    }
  public void buildChooser() {
    setLayout(new GridLayout(3, 4));
    setBackground(Color.decode("#3E3E3E"));
    makeAddButton("White", Color.white);
    makeAddButton("Black", Color.black);
    makeAddButton("Gray", Color.darkGray);
    makeAddButton("Gray", Color.gray);
    makeAddButton("Gray", Color.blue);
    makeAddButton("Cyan", Color.cyan);
    makeAddButton("Green", Color.green);
    makeAddButton("Orange", Color.ORANGE);
    makeAddButton("Yellow", Color.yellow);
    makeAddButton("Pink", Color.pink);
    makeAddButton("Magenta", Color.MAGENTA);
    makeAddButton("Red", Color.red);
    

  }

  public void updateChooser() {
  }

  public String getDisplayName() {
    return "MyChooserPanel";
  }

  public Icon getSmallDisplayIcon() {
    return null;
  }
  public Icon getLargeDisplayIcon() {
    return null;
  }
  private void makeAddButton(String name, Color color) {
    JButton button = new JButton(name);
    button.setBackground(color);
    button.setPreferredSize(new Dimension(20, 20));
    //button.setFocusable(false);
        //fill.setFocusPainted(false);
    button.setBorder(new LineBorder(Color.BLACK));
    button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.decode("#3E3E3E"), 2),   
            BorderFactory.createLineBorder(Color.black, 0)));
    button.setAction(setColorAction);
    dp.color = color;
    add(button);
  }

  Action setColorAction = new AbstractAction() {
    public void actionPerformed(ActionEvent evt) {
      JButton button = (JButton) evt.getSource();

      getColorSelectionModel().setSelectedColor(button.getBackground());
    }
  };
}