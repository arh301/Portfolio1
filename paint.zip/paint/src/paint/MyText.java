package paint;

import paint.DrawPanel.Tools;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class MyText 
    implements Drawable {
    public DrawPanel dp;
    private double x1, y1, x2, y2;
    public Color fill;
    public String text;
    public Color stroke;
    public JTextArea tf;
     DocumentListener docListener = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent de) {
                
                tf.setEditable(true);
                tf.requestFocusInWindow();
                dp.activeT = tf;
                
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                                        System.out.println("text active");

                JTextArea te = (JTextArea) de.getDocument().getProperty(de);
                if(dp.tool == Tools.delete){
                    te.setEditable(false);
                    dp.shapesList.remove(this);
                    dp.textList.remove(te);
                    dp.repaint();
                }
                else{
                
                dp.activeT = te;
               te.requestFocusInWindow();
                
            }
        };
     };
    public MyText(double x1, double y1, double x2, double y2, DrawPanel dp) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        tf = new JTextArea();
        tf.setLocation((int)x1,(int)y1 );
        tf.setSize((int)(x2-x1), (int)(y2-y1));
        tf.setEditable(true);
        tf.setLineWrap(true);
        System.out.println("create text");
        stroke = Color.BLACK;
        text= "TEXT";
        tf.getDocument().addDocumentListener(docListener);
        this.dp = dp;
        
        
    }
   public void setFocus(JTextArea tf){
       tf.requestFocusInWindow();
   }
    
  

    @Override
    public void draw(Graphics2D g) {
        double x = getStartX();
        double y = getStartY();
        double width = getWidth();
        double height = getHeight();
     
                if (fill != null) {
                        tf.setBackground(fill);
                               }
                if(tf != null){
        tf.setLocation((int)x1,(int)y1 );
        tf.setSize((int)(x2-x1), (int)(y2-y1));
                }
        g.setPaint(stroke);
        g.draw(new Rectangle2D.Double(x - 1, y -  1, width + 2, height + 2));
        
    }

    private double getStartX() {
        return Math.min(x1, x2);
    }

    private double getStartY() {
        return Math.min(y1, y2);
    }

    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if (getStartX() <= xcheck && xcheck <= getStartX() + getWidth() && getStartY() <= ycheck && ycheck <= getStartY() + getHeight()) {
            contains = true;
            return contains;
        } else {
            return contains;
        }
    }

     @Override
    public double getX() {
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }

    @Override
    public double getWidth() {
        return Math.abs(x1 - x2);
    }

    @Override
    public double getHeight() {
        return Math.abs(y1 - y2);
    }

    @Override
    public void setColor(Color color) {
        stroke = color;
    }

    @Override
    public Color getColor() {
        return stroke;
    }

    @Override
    public void setFill(Color fill) {
        this.fill = fill;

    }

    @Override
    public String getShape() {
        return "text";
    }
@Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

    
   
    
}
