/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author Anna
 */
public class MySquare implements Drawable{
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

	private double x1, y1, y2, x2;
        public Color fill;
        public Color stroke;
        public Double radius;

	public MySquare() {
	}

	public MySquare(double x1, double y1, double x2, double y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
                stroke = Color.BLACK;
                radius = getRadius();
	}
	
	@Override
	public void draw(Graphics2D g) {

			Rectangle2D.Double squ = new Rectangle2D.Double(x1 - radius, y1 - radius, 2.0 * radius, 2.0 * radius);
			
                        if (fill != null){
                            g.setPaint(fill);
                        g.fill(squ);
                }
            
                        g.setPaint(stroke);
			g.draw(new Rectangle2D.Double(x1 - radius, y1 - radius, 2.0 * radius, 2.0 * radius));
		
	}

	public double getRadius() {
                radius = (x2-x1)/2;
		return radius;
	}

	private double getStartX() {
            
                double midX = getX();
		return midX - radius;
	}

	private double getStartY() {
                double midY = getY();
		return midY - radius;
	}

	


    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        radius = getRadius();
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if(getStartX() <= xcheck &&  xcheck <= getStartX()+ (radius*2) && getStartY() <= ycheck &&  ycheck <= getStartY() + (radius*2) ){
            contains = true;
            return contains;
        }
        else{
            return contains;
        }    }

    @Override
    public double getX() {
        
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }
    @Override
    public void setColor(Color color) {
        stroke = color;
    }
    @Override
    public Color getColor() {
        return stroke;
    }

    

    @Override
    public double getWidth() {
        double width = radius*2;
        return width;
    }

    @Override
    public double getHeight() {
         double height = radius*2;
        return height;
    }
    @Override
    public String getShape() {
        return "squ";
    }

    @Override
    public void setFill(Color color) {
        fill = color;
        }
    @Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

    
}    


