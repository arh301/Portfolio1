/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import static paint.DrawPanel.Tools.move;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import javax.swing.BorderFactory;

/**
 *
 * @author Anna
 */
public class MyCircle implements Drawable {

    private double x1, y1, y2, x2;
    public Color stroke;
    public Color fill;
    public Double radius;

    public MyCircle() {
    }

    public MyCircle(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        stroke = Color.BLACK;
        fill = null;
        radius = getRadius();
    }

    @Override
    public void draw(Graphics2D g) {
        double x = getX();
        double y = getY();
        

        Ellipse2D cir = new Ellipse2D.Double(x - radius, y - radius, 2.0 * radius, 2.0 * radius);

        if (fill != null) {
            g.setColor(fill);          
            g.fill(cir);          
            g.setColor(stroke);            
            g.draw(new Ellipse2D.Double(x1 - radius, y1 - radius, 2.0 * radius, 2.0 * radius)); 
        }
        else{
            g.setColor(stroke);
        }
        g.draw(cir);

    }

    public double getRadius() {
        double maxX = Math.max(x2,x1);
        double maxY = Math.max(y2,y1);
        double minY = Math.min(y2,y1);
        double minX = Math.min(x2,x1);
        radius = Math.sqrt((Math.pow((maxX - minX), 2)) + (Math.pow((maxY - minY), 2)));
        return radius;
    }

    private double getStartX() {

        double midX = getX();
        return midX - radius;
    }

    private double getStartY() {
        double midY = getY();
        return midY - radius;
    }

    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {

        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        radius = getRadius();
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if (getStartX() <= xcheck && xcheck <= getStartX() + (radius * 2) && getStartY() <= ycheck && ycheck <= getStartY() + (radius * 2)) {
            contains = true;
            return contains;
        } else {
            return contains;
        }
    }

    @Override
    public double getX() {

        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }

    @Override
    public void setColor(Color color) {
        stroke = color;

    }

    @Override
    public Color getColor() {
        return stroke;
    }

    @Override
    public void setFill(Color color) {
        fill = color;
    }

    @Override
    public double getWidth() {
        
        return radius;
    }

    @Override
    public double getHeight() {
        return radius;
        
    }

    @Override
    public String getShape() {
        return "cir";
    }

    @Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

}
