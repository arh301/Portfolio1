package paint;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


public class MyLine implements Drawable {

	public double x1, y1, y2, x2;
        public Color stroke;
        public Color fill;
        Line2D line;


	public MyLine(double x1, double y1, double x2, double y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
                stroke = Color.BLACK;
	}
        
	
	@Override
	public void draw(Graphics2D g) {
	
			double x = getStartX();
			double y = getStartY();
			double width = getWidth();
			double height = getHeight();
			line = new Line2D.Double(x1, y1, x2, y2);
                       
			
			g.draw(line);
		
	}

        @Override
	public double getWidth() {
		return Math.abs(x2 - x1);
	}

        @Override
	public double getHeight() {
		return Math.abs(y2 - y1);
	}

	private double getStartX() {
		return Math.min(x1, x2);
	}

	private double getStartY() {
		return Math.min(y1, y2);
	}


    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        if(x1 >= x2){
            this.x1 = x2;
            this.x2 = x1;
        }
        else{
           this.x1 = x1;
        this.x2 = x2; 
        }
        if(y1 >= y2){
            this.y1= y2;
            this.y2 = y1;
        }
        else{
           this.y1 = y1;
        this.y2 = y2; 
        }
        
        
    }

    @Override
    public boolean contains(int x, int y) {
        int boxX = x - 1;
int boxY = y - 1;

int width = 3;
int height = 3;


	if (line.intersects(boxX, boxY, width, height)) {
		return true;
	}
        else{
            return false;
}
//                boolean contains = false;
//        double xcheck = (double) x;
//        double ycheck = (double) y;
//        if(x1 <= xcheck &&  xcheck <= x2 && y1 <= ycheck &&  ycheck <= y2 ){
//            contains = true;
//            return contains;
//        }
//        else{
//            return contains;
//        }    }
    }
    @Override
    public double getX() {
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }
    @Override
    public void setColor(Color color) {
        stroke = color;
    }
    @Override
    public Color getColor() {
        return stroke;
    }
    
    @Override
    public void setFill(Color fill){
        this.fill = fill;
    }
    @Override
    public String getShape() {
        return "line";
    }

    @Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

    }

	

