package paint;

import java.awt.Color;
import java.awt.Graphics2D;

public interface Drawable {


    public void draw(Graphics2D g);

    public void setCoordinates(double x1, double y1, double x2, double y2);

    public boolean contains(int x, int y);

    public double getX();

    public double getY();
    
    public double getWidth();
    
    public void setX1(double x1);
    
    public void setY1(double y1);
    
    public double getHeight();
    
    public void setColor(Color color);
    
    public Color getColor();
    
    public void setFill(Color color);

    public String getShape();
    
}
