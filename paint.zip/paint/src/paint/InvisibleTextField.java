package paint;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class InvisibleTextField extends JTextField
        implements ActionListener, FocusListener, MouseListener, DocumentListener {

    public String textOut;
    public MyText textbox;

    public InvisibleTextField(MyText textbox) {
       this.textbox = textbox;
        
        setOpaque(false);
        setColumns(1);
        setSize((int)textbox.getWidth(), (int)textbox.getHeight());
        setColumns(0);
        addActionListener(this);
        addFocusListener(this);
        addMouseListener(this);
       
        textOut = "text";
    }

//  Implement ActionListener
    @Override
    public void actionPerformed(ActionEvent e) {
        textOut =  this.getText();
        setEditable(false);
    }

//  Implement FocusListener
    @Override
    public void focusLost(FocusEvent e) {
        setEditable(false);
    }

    @Override
    public void focusGained(FocusEvent e) {
    }

//  Implement MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            setEditable(true);
            
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        setEditable(true);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

//  Implement DocumentListener
    @Override
     public void changedUpdate(DocumentEvent e) {
    updateSize();
    textOut = e.toString();
    printIt(e);
  }
  public void removeUpdate(DocumentEvent e) {
    updateSize();
    textOut = getText();
        printIt(e);

  }
  public void insertUpdate(DocumentEvent e) {
    updateSize();
    textOut = getText();
        printIt(e);

  }
  
  private void printIt(DocumentEvent documentEvent) {
        DocumentEvent.EventType type = documentEvent.getType();
        String typeString = null;
        if (type.equals(DocumentEvent.EventType.CHANGE)) {
          typeString = "Change";
        }  else if (type.equals(DocumentEvent.EventType.INSERT)) {
          typeString = "Insert";
        }  else if (type.equals(DocumentEvent.EventType.REMOVE)) {
          typeString = "Remove";
        }
        System.out.print("Type : " + typeString);
        Document source = documentEvent.getDocument();
        int length = source.getLength();
        System.out.println("Length: " + length);
      }

    private void updateSize() {
        this.setSize((int)textbox.getWidth(), (int)textbox.getHeight());
    }

   
}
