package paint;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DrawPanel extends JPanel {

    public ArrayList<Drawable> shapesList;
    public Color color;
    public Graphics g;
    public int p;
    public int x;
    public int y;
    public Drawable active;
    public ArrayList<JTextArea> textList;
    public int endX;
    public int endY;
    public boolean released;
    public boolean pressed;
    public double fromX;
    public double fromY;
    public int clicks;
    public Window window;
    public Tools tool;
    public double preY;
    public double preX;
    public Drawable shape;
    public MyText text;
    public Graphics2D g2d;
    public Tools lastTool;
    public JTextArea activeT;
    public StopWatch sw;

    public void resetClicks() {
clicks = 0;    }
    

    

    public enum Tools {
        shape, placeRec, placeEll, placeLine, placeCir, delete, resize, move, outline, fill, text, placeSqu, image, newP, save
    };

    public DrawPanel(Window w) {
        super();
        sw = new StopWatch();
        clicks = 0;
        color = Color.BLACK;
        shape = null;
        window = w;
        active = null;
        released = false;
        shapesList = new ArrayList<>();
        textList = new ArrayList<>();
        x = 0;
        y = 0;
        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent me) {
                
                x = me.getX();
                y = me.getY();

                active = null;

                released = true;
                paint();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                clicks++;
                
                preX = me.getX();
                x = me.getX();
                y = me.getY();
                endX = me.getX();
                endY = me.getY();
                preY = me.getY();
                active = null;
                pressed = true;
                released = false;
                paint();
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                endX = me.getX();
                endY = me.getY();
                x = me.getX();
                y = me.getY();
                pressed = false;
                released = true;
                paint();

            }

            @Override
            public void mouseEntered(MouseEvent me) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseExited(MouseEvent me) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

        });
        this.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent me) {
                x = me.getX();
                y = me.getY();
                endX = me.getX();
                endY = me.getY();
                released = false;
                paint();
            }

            @Override

            public void mouseMoved(MouseEvent me) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        }
        );
    
    }
    

    public void setpreX(double x) {
        preX = x;
    }

    public void setpreY(double y) {
        preY = y;

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g2d = (Graphics2D) g;
        if (shapesList.size() >= 1) {
            for (Drawable s : shapesList) {
                g2d.setPaint(s.getColor());
                s.draw(g2d);
               
            }
        }
        if (textList.size() >= 1) {
            for (JTextArea s : textList) {
                this.add(s);
                if (activeT != null) {
                    activeT.requestFocusInWindow();

                }
            }
        }

    }

    public void paint() {
        if (tool != null) {

            switch (tool) {

                case placeRec:
                    if (pressed == true) {
                        shape = new MyRectangle(preX, preY, (preX + 1), (preY + 1));
                        shapesList.add(shape);
                        repaint();
                    }
                    if (released == false) {
                        pressed = false;
                        shape.setCoordinates(preX, preY, x, y);
                        repaint();
                    }
                    if (released != false && x != 0 && y != 0) {
                        shape.setCoordinates(preX, preY, endX, endY);

                    }
                    break;

                case placeCir:
                    if (pressed == true) {
                        shape = new MyCircle(preX, preY, (preX + 1), (preY + 1));
                        shapesList.add(shape);
                        repaint();
                    }
                    if (released == false) {
                        pressed = false;
                        shape.setCoordinates(preX, preY, x, y);
                        repaint();
                    }

                    break;
                case placeSqu:
                    if (pressed == true) {
                        shape = new MySquare(preX, preY, endX, endY);
                        shapesList.add(shape);
                        repaint();
                    }
                    if (released == false) {
                        pressed = false;
                        shape.setCoordinates(preX, preY, x, y);
                        repaint();
                    }
                    break;

                case placeEll:
                    if(pressed == true ){
                        System.out.println(preX);
                        System.out.println(preY);
                        shape = new MyEllipse(preX, preY, preX + 1, preX + 1);
                        shapesList.add(shape);
                        repaint();
                    }
                    if (released == false ) {
                        pressed = false;
                        shape.setCoordinates(preX, preX, endX, endY);
                        
                        repaint();
                    }
                    
                    break;

                case placeLine:
                    if (released == true && x != 0 && y != 0) {
                        shape = new MyLine(preX, preY, endX, endY);
                        shapesList.add(shape);
                        repaint();
                    }

                    break;
                case resize:
                    if (active == null) {
                        for (Drawable s : shapesList) {
                            if (s.contains(x, y) == true) {
                                active = s;
                                setpreX(s.getX());
                                setpreY(s.getY());
                            }
                        }
                    }

                    if (active != null) {
                        if (released == true) {
                            active = null;
                            x = 0;
                            y = 0;

                        } else {
                            active.setCoordinates(active.getX(), active.getY(), x, y);

                            repaint();
                        }
                    }

                    break;

                case move:

                    if (active == null) {
                        for (Drawable s : shapesList) {
                            if (s.contains(x, y) == true) {
                                active = s;
                                double minX = Math.min(preX, s.getX());
                                double maxX = Math.max(preX, s.getX());
                                double minY = Math.min(preY, s.getY());
                                double maxY = Math.max(preY, s.getY());
                                fromX = maxX - minX;
                                fromY = maxY - minY;
                            }
                        }
                    }
                    if (active != null) {
                        if (active.getShape() == "cir") {
                            active.setX1(x);
                            active.setY1(y);
                            repaint();
                        } 
                        else if (active.getShape() == "line") {
                                                        active.setCoordinates((x - fromX), (y - fromY), ((x - fromX) + active.getWidth()), ((y - fromY) + active.getHeight()));

                        }
                        
                        else if(released == false) {
                            active.setCoordinates((x - fromX), (y - fromY), ((x - fromX) + active.getWidth()), ((y - fromY) + active.getHeight()));
                            
                            repaint();
                        }
                        if (released == true) {
                            x = 0;
                            y = 0;
                            repaint();
                            //shapesList.remove(active);
                            active = null;
                        }
                    }

                    break;
                case image:
                    repaint();
                    break;

                case text:

//                    while(activeT != null){
//                        activeT.setEditable(true);
//                        activeT.requestFocusInWindow();
//                    }

//                    if(activeT == null){
                    if (released == true) {

                        text = new MyText(preX, preY, endX, endY, this);

                        text.tf.setEditable(true);
                        textList.add(text.tf);
                        text.tf.requestFocusInWindow();
                        shapesList.add(text);

                        repaint();
                        text.tf.requestFocusInWindow();
                    }
//                        }

                    break;

                case delete:
                    Drawable delete = null;
                    JTextArea deleteT = null;
//                    for(JTextArea s: textList){
//                        s.setEditable(false);
//                    }

                    if(activeT != null){
                        for(Drawable s: shapesList){
                            if (s.getShape() == "text") {
                                MyText textbox = (MyText) s;
                                if (textbox.tf == activeT) {
                                    textList.remove(deleteT);
                                    
                        repaint();
                               }

                    }}}
                        

                    for (Drawable s : shapesList) {
                        if (s.contains(x, y) == true) {

                            delete = s;
                        }
                    }
//                    for (JTextArea t : textList) {
//                        for(Drawable s: shapesList){
//                            if (s.getShape() == "text"){
//                                MyText textbox = (MyText)s;
//                                if(t.contains())
//                            }
//                        }
//                        if (t.contains(x, y) == true) {
//
//
//                            deleteT = t;
//                        }
//                    }

                    if (delete != null) {
                        if (delete.getShape() == "text"){

                        MyText textbox = (MyText)delete;
                        for (JTextArea t : textList) {
                            if (textbox.tf == t){
                                deleteT = t;
                            }
                        }
                    }
                        shapesList.remove(delete);
                        repaint();
                    }
                    if (deleteT != null) {

                        textList.remove(deleteT);
                        this.remove(deleteT);
                        repaint();
                    }

                    break;

                case outline:

                    lastTool = Tools.outline;
                    for (Drawable s : shapesList) {

                        if (s.contains(x, y) == true) {

                            s.setColor(color);
                            repaint();
                        }
                    }
                    break;

                case fill:
                    lastTool = Tools.fill;
                    for (Drawable s : shapesList) {
                        if (s.contains(x, y) == true) {
                            s.setFill(color);
                            repaint();
                        }
                    }

                    break;
                default:

            }
        } 

    }

    public Drawable returnShape() {
        return shape;
    }

    public void setNewColor(Color color) {
        this.color = color;
    }

    public void randomColor() {
        Color costumColor = new Color(randomNumber(), randomNumber(), randomNumber());
        setNewColor(costumColor);
        repaint();
    }

    private int randomNumber() {
        return (int) (Math.random() * 256 - 1);
    }

}

