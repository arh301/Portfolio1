package paint;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

public class MyRectangle implements Drawable {

    private double x1, y1, x2, y2;
    public Color fill;
    public Color stroke;

    public MyRectangle() {
    }

    public MyRectangle(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        stroke = Color.BLACK;
    }

    @Override
    public void draw(Graphics2D g) {
        double x = getStartX();
        double y = getStartY();
        double width = getWidth();
        double height = getHeight();
        Rectangle2D rec = new Rectangle2D.Double(x, y, width, height);

        if (fill != null) {
            g.setPaint(fill);
            g.fill(rec);
        }
        g.setPaint(stroke);
        g.draw(new Rectangle2D.Double(x, y, width, height));
    }

    public double getWidth() {
        return Math.abs(x1 - x2);
    }

    public double getHeight() {
        return Math.abs(y1 - y2);
    }

    private double getStartX() {
        return Math.min(x1, x2);
    }

    private double getStartY() {
        return Math.min(y1, y2);
    }

    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if (getStartX() <= xcheck && xcheck <= getStartX() + getWidth() && getStartY() <= ycheck && ycheck <= getStartY() + getHeight()) {
            contains = true;
            return contains;
        } else {
            return contains;
        }
    }

    @Override
    public double getX() {
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }

    @Override
    public void setColor(Color color) {
        stroke = color;
    }

    @Override
    public Color getColor() {
        return stroke;
    }

    @Override
    public void setFill(Color fill) {
        this.fill = fill;

    }

    @Override
    public String getShape() {
        return "rec";
    }
@Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }
}
