package paint;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public class MyEllipse implements Drawable {

    private double x1, y1, y2, x2;
    public Color stroke;
    public Color fill;

    public MyEllipse() {
    }

    public MyEllipse(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        stroke = Color.BLACK;
    }

    @Override
    public void draw(Graphics2D g) {

        double x = getStartX();
        double y = getStartY();
        double width = getWidth();
        double height = getHeight();
         
        
        Ellipse2D ell = new Ellipse2D.Double(x, y, width, height);
        if (fill != null) {
            g.setPaint(fill);
            g.fill(ell);
            g.setPaint(stroke);
            g.draw(new Ellipse2D.Double(x, y, width, height));
        }
        else{
            g.setColor(stroke);
        }
        
        g.draw(ell);

    }

    public double getWidth() {
        return Math.abs(x1 - x2);
    }

    public double getHeight() {
        return Math.abs(y1 - y2);
    }

    private double getStartX() {
        return Math.min(x1, x2);
    }

    private double getStartY() {
        return Math.min(y1, y2);
    }

    @Override
    public void setCoordinates(double x1, double y1, double x2, double y2) {

        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public boolean contains(int x, int y) {
        boolean contains = false;
        double xcheck = (double) x;
        double ycheck = (double) y;
        if (getStartX() <= xcheck && xcheck <= getStartX() + getWidth() && getStartY() <= ycheck && ycheck <= getStartY() + getHeight()) {
            contains = true;
            return contains;
        } else {
            return contains;
        }
    }

    @Override
    public double getX() {
        return x1;
    }

    @Override
    public double getY() {
        return y1;
    }

    @Override
    public void setColor(Color color) {
        stroke = color;
    }

    @Override
    public Color getColor() {
        return stroke;
    }

   
    @Override
    public String getShape() {
        return "ell";
    }

    @Override
    public void setFill(Color color) {
    fill = color;
    }
    @Override
    public void setX1(double x1) {
    this.x1 = x1;    }

    @Override
    public void setY1(double y1) {
        this.y1 = y1;
    }

  

}
