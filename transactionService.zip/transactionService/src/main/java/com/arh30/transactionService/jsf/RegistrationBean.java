package com.arh30.transactionService.jsf;

import com.arh30.transactionService.ejb.UserService;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

// JSF bean to implement the registration view (regisration.xhtml) and forward user inputs to create new users.
// Connects UserService EJB to access the persistence layer and create a new user.
// Auto-generated Getter and Setter methods and override methods are included
@Named(value = "registrationBean")
@RequestScoped
public class RegistrationBean {

    @EJB
    UserService usrSrv;

    String username;
    String userpassword;
    String name;
    String currency;
    String success;

    public RegistrationBean() {

    }

    // Method to call respective EJB method, attempting to register a new user with the parameters passed
    // Returns success/error message depending on the reuslt of the EJB method
    public void register() {
        String made = usrSrv.registerUser(username, userpassword, name, currency);
        if (made == "true") {
            success = "Account sucessfully created, you may now go back and login";
        } else if(made == "userExists"){
            success = "Error creating account, username already exists";
        }
        else {
            success = "Error creating account, please try again";
        }
    }

    // Getter method for success (message)
    public String getSuccess() {
        return success;
    }

    // Setter method for success (message)
    public void setSuccess(String success) {
        this.success = success;
    }

    // Getter method for userSrv
    public UserService getUsrSrv() {
        return usrSrv;
    }

    // Setter method for userSrv
    public void setUsrSrv(UserService usrSrv) {
        this.usrSrv = usrSrv;
    }

    // Getter method for username
    public String getUsername() {
        return username;
    }

    // Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for userpassword
    public String getUserpassword() {
        return userpassword;
    }

    // Setter method for userpassword
    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    // Getter method for name
    public String getName() {
        return name;
    }

    // Setter method for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for currency
    public String getCurrency() {
        return currency;
    }

    // Setter method for currency
    public void setCurrency(String currency) {
        this.currency = currency;
    }

}
