package com.arh30.transactionService.jsf;

import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

// JSF bean to implement the logout functionality of index.xhtml
@Named
@RequestScoped
public class LoginBean implements Serializable {
    
    String success; // variable to hold success/error message for logout function

    // Getter method for success
    public String getSuccess() {
        return success;
    }

    // Setter method for success
    public void setSuccess(String success) {
        this.success = success;
    }
    // Method logs user out using FacesContext and HttpServletRequest to get user and logout
    public void logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        try {
            //this method will disassociate the principal from the session (effectively logging him/her out)
            request.logout();
            success = "User logged out";
        } catch (ServletException e) {
            success = "Error logging out";
        }
    }
}
