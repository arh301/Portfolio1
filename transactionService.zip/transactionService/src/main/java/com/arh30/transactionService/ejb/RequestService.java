package com.arh30.transactionService.ejb;

import com.arh30.transactionService.entity.Requests;
import com.arh30.transactionService.entity.SystemUser;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

// Stateless EJB for functionality of requests.xhtml 
// Accesses data through an Entity Manager to create request records and return lists of requests
// Declarative security restricts EJB access to authorised users and admins 
@Stateless
@DeclareRoles({"users", "admins"})
@RolesAllowed({"users", "admins"})

public class RequestService {

    @PersistenceContext(unitName = "WebappsPU")
    EntityManager em;

    // Method to create new request record in Requests
    public boolean write(String usernameD, String usernameC, double amount) {
        SystemUser debtor = em.find(SystemUser.class, usernameD);
        SystemUser requesting = em.find(SystemUser.class, usernameC);
        if (debtor == null) { // If the inputed user does not exist, return false
            return false;
        }
        // Create request, using the currency of the user requesting payment
        String senderCur = requesting.getCurrency();
        Requests request;
        request = new Requests(usernameD, usernameC, amount, senderCur);
        // Push data to the database using the Entity Manager
        em.persist(request);
        em.flush();
        return true;

    }

    // Method to return currency of the user making request
    public String getCurrency(String usernameD) {
        SystemUser sender = em.find(SystemUser.class, usernameD);
        return sender.getCurrency();
    }

    // Getter method for EntityManager em
    public EntityManager getEm() {
        return em;
    }

    // Setter method for EntityManager em
    public void setEm(EntityManager em) {
        this.em = em;
    }

    // Method to return list of requests returns unusual error, reason could not be determined
    // Uncommented code acts to prevent error crashing the application
    public synchronized List getRequestsList1(String usernameD) {
        //List requests = em.createQuery("SELECT r FROM Requests r WHERE r.usernameD = :usernameD").setParameter("usernameD", usernameD).getResultList();
        //Collections.reverse(requests); //reorders the list so most recent appear at the top
        //      return requests;
        List list = new ArrayList() {
        };
        return list;
    }

    //Method to return list of requests returns unusual error, reason could not be determined
    // Uncommented code acts to prevent error crashing the application
    public synchronized List getRequestsList2(String usernameC) {
        //List requests = em.createQuery("SELECT r FROM Requests r WHERE r.usernameC = :usernameC").setParameter("usernameC", usernameC).getResultList();
        //Collections.reverse(requests); //reorders the list so most recent appear at the top
        //      return requests;
        List list = new ArrayList() {
        };
        return list;
    }
}
