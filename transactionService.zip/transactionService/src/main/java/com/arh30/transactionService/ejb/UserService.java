package com.arh30.transactionService.ejb;

import com.arh30.transactionService.entity.SystemUser;
import com.arh30.transactionService.entity.SystemUserGroup;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.annotation.security.PermitAll;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

// Stateless EJB to provide user registration functionality using an EntityManager to add user data
// Declarative security restricts EJB access to authorised users and admins 
@Stateless
@PermitAll
@TransactionManagement(TransactionManagementType.CONTAINER)
public class UserService {

    @PersistenceContext
    EntityManager em;

    public UserService() {
    }

    // Method to register new user, using the paramaters provided by the user in registration.xhtml
    // Password is encrypted and user record is added to the SystemUser entity using the EntityManager
     // Creates transaction to ensure users created at the same time cannot create duplicate IDs
    @TransactionAttribute(REQUIRED)
    public String registerUser(String username, String userpassword, String name, String currency) {
        try {
            // Return error if username already exists
            SystemUser query = em.find(SystemUser.class, username);
            if(query != null){
                return "userExists";
            }
            SystemUser sys_user;
            SystemUserGroup sys_user_group;
            // Creates encrypted password to be saved to database
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String paswdToStoreInDB = bigInt.toString(16);
            // Sets initial balance to £1000 or converts the balance according to EUR or USD conversion rates
            int amount = 1000;
            if ("USD".equals(currency)) {
                amount = (int) (1000 * 1.29);
            }
            if ("EUR".equals(currency)) {
                amount = (int) (1000 * 1.18);
            }
            // Creates new Entity objects for new user
            sys_user = new SystemUser(username, paswdToStoreInDB, name, amount, currency, "users");
            sys_user_group = new SystemUserGroup(username, "users");
            //Adds data records to entities SystemUser and SystemUserGroup, using the Entity Manager
            em.persist(sys_user);
            em.persist(sys_user_group);
            return "true";
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            return "false";
        }
    }

}
