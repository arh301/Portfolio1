package com.arh30.transactionService.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

// Transactions Entity represents the Transactions table and each instance represents a record in the table, with columns
// id, usernameD, usernameC, amount and currency.
// All fields are annotated @NotNull to ensure mandatory entry for creating a new record
// Auto-generated Getter and Setter methods and override methods are included
@Entity
@Table
// NamedQueries, used by the TransService EJB, search for transactions on username 
@NamedQueries({
    @NamedQuery(query = "Select t from Transactions t where t.usernameD = :usernameD", name = "findTrans"),
    @NamedQuery(query = "Select t from Transactions t where t.usernameC = :usernameD", name = "findTrans2"),})

public class Transactions implements Serializable {

    // Id is an auto-generated field to provide a random unique id, remaining fields are set via the contructor
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    String usernameD;

    @NotNull
    String usernameC;

    @NotNull
    double amount;

    @NotNull
    String currency;

    public Transactions() {
    }

    public Transactions(String usernameD, String usernameC, double amount, String currency) {
        this.usernameD = usernameD;
        this.usernameC = usernameC;
        this.amount = amount;
        this.currency = currency;
    }

    // Getter method for id
    public Long getId() {
        return id;
    }

    // Setter method for id
    public void setId(Long id) {
        this.id = id;
    }

    // Getter method for usernameD
    public String getUsernameD() {
        return usernameD;
    }

    // Setter method for usernameD
    public void setUsernameD(String usernameD) {
        this.usernameD = usernameD;
    }

    // Getter method for usernameC
    public String getUsernameC() {
        return usernameC;
    }

    // Setter method for usernameC
    public void setUsernameC(String usernameC) {
        this.usernameC = usernameC;
    }

    // Getter method for currency
    public String getCurrency() {
        return currency;
    }

    // Setter method for currency
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    // Getter method for amount
    public double getAmount() {
        return amount;
    }

    // Setter method for amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Override method for hashCode() function
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.usernameC);
        hash = 97 * hash + Objects.hashCode(this.usernameD);
        return hash;
    }

    // Override method for equals(Object obj) function
    @Override
    public boolean equals(Object obj) {
        return true;
    }

    // Override method for toString() function
    @Override
    public String toString() {
        return "Transactions[ id=" + id + " ]";
    }

}
