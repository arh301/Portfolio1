package com.arh30.transactionService.jsf;

import com.arh30.transactionService.ejb.AdminService;
import com.arh30.transactionService.entity.Transactions;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

// JSF bean to implement the admin views (/faces/admins/ newAdmin.xhtml, trans.html and users.html)
// Connects AdminService EJB to access the persistence layer/entities and perform functionality
// Auto-generated Getter and Setter methods and override methods are included
@Named
@RequestScoped
public class AdminBean {

    @EJB
    AdminService adminSrv;
    String username;
    String userpassword;
    String name;
    String success; // Success/error message string

    public AdminBean() {

    }

    // Method to call respective EJB method, returning a list of all transactions 
    public List<Transactions> getTransList() {
        return adminSrv.getTransList();
    }

    // Method to call respective EJB method, returning a list of all users
    public List<Transactions> getUserList() {
        return adminSrv.getUserList();
    }

    // Method to call respective EJB method and passing parameters from newAdmin.xhtml
    // To create new admin user
    public void register() {
        String done = adminSrv.registerAdmin(username, userpassword, name);
        if(done == "true"){
            success = "Account successfully created";
        }
        else if(done == "userExists"){
            success = "Error - username already exists";
        }
        else{
            success = "Failed to create account, please try again.";
        }
        
    }

    // Getter method for success, the scope for the success/error message displayed to the user
    public String getSuccess() {
        return success;
    }

    // Setter method for success
    public void setSuccess(String success) {
        this.success = success;
    }

    // Getter method for adminSrv
    public AdminService getAdminSrv() {
        return adminSrv;
    }

    // Setter method for adminSrv
    public void setAdminSrv(AdminService adminSrv) {
        this.adminSrv = adminSrv;
    }

    // Getter method for username
    public String getUsername() {
        return username;
    }
    
    // Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for userpassword
    public String getUserpassword() {
        return userpassword;
    }

    // Setter method for userpassword
    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    // Getter method for name
    public String getName() {
        return name;
    }
    
    // Setter method for name
    public void setName(String name) {
        this.name = name;
    }

    

}
