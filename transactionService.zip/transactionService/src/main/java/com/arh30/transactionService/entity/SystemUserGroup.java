package com.arh30.transactionService.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

// SystemUserGroup Entity represents the SystemUserGroup table and each instance represents a record in the table, with columns
// id, username and groupname.
// All fields are annotated @NotNull to ensure mandatory entry for creating a new record
// Auto-generated Getter and Setter methods and override methods are included
@Entity
public class SystemUserGroup implements Serializable {

    // Id is an auto-generated field to provide a random unique id, remaining fields are set via the contructor
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String groupname;

    public SystemUserGroup() {
    }

    // Constructor creates new record/row in the SystemsUserGroup table, setting all fields excluding id
    public SystemUserGroup(String username, String groupName) {
        this.username = username;
        this.groupname = groupName;
    }

    // Getter method for id
    public Long getId() {
        return id;
    }

    // Setter method for id
    public void setId(Long id) {
        this.id = id;
    }

    // Getter method for username
    public String getUsername() {
        return username;
    }

    // Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for groupname
    public String getGroupName() {
        return groupname;
    }

    // Setter method for groupname
    public void setGroupName(String groupName) {
        this.groupname = groupName;
    }

    // Override method for hashCode function
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.id);
        hash = 47 * hash + Objects.hashCode(this.username);
        hash = 47 * hash + Objects.hashCode(this.groupname);
        return hash;
    }

    // Override method for equals function
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SystemUserGroup other = (SystemUserGroup) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.groupname, other.groupname)) {
            return false;
        }
        return true;
    }

}
