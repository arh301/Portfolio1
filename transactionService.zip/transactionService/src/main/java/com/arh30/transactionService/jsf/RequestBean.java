package com.arh30.transactionService.jsf;

import com.arh30.transactionService.ejb.RequestService;
import com.arh30.transactionService.entity.Requests;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

// JSF bean to implement the request view (regisration.xhtml) functionality, i.e. making new requests 
// Connects RequestService EJB to access the persistence layer and create a new requests
// Auto-generated Getter and Setter methods and override methods are included
@Named(value = "requestBean")
@RequestScoped
public class RequestBean {

    @EJB
    RequestService requestSrv;
    String usernameD;
    String usernameC;
    double amount;
    String success;

    public RequestBean() {
        // Set the requesting/creditor user for the request, using FacesContext methods
        usernameC = FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal().getName();
    }

    // Method to call respective EJB method, attempting to make a request using passed parameters from request.xhtml
    // Returns success/error message depending on the reuslt of the EJB method
    public void makeRequest() {
        boolean made = requestSrv.write(usernameD, usernameC, amount);
        if (made) {
            success = "Request successfully made";
        } else {
            success = "Error making request, check username is valid";
        }
    }

    // Method to call respective EJB method, attempting to return a list of all requests pending
    // This method does not work, unknown error returned on SQL query - see EJB 
    public List<Requests> getRequestsList1() {
        return requestSrv.getRequestsList1(usernameC);
    }

    // Method to call respective EJB method, attempting to return a list of all requests pending
    // This method does not work, unknown error returned on SQL query - see EJB 
    public List<Requests> getRequestsList2() {
        return requestSrv.getRequestsList2(usernameC);
    }

    // Getter method for success
    public String getSuccess() {
        return success;
    }

    // Setter method for success
    public void setSuccess(String success) {
        this.success = success;
    }

    // Getter method for requestSrv
    public RequestService getRequestSrv() {
        return requestSrv;
    }

    // Setter method for requesSrv
    public void setRequestSrv(RequestService requestSrv) {
        this.requestSrv = requestSrv;
    }

    // Getter method for usernameD
    public String getUsernameD() {
        return usernameD;
    }

    // Setter method for usernameD
    public void setUsernameD(String usernameD) {
        this.usernameD = usernameD;
    }

    // Getter method for usrnameC
    public String getUsernameC() {
        return usernameC;
    }

    // Setter method for usernameC
    public void setUsernameC(String usernameC) {
        this.usernameC = usernameC;
    }

    // Getter method for amount
    public double getAmount() {
        return amount;
    }

    // Setter method for amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

}
