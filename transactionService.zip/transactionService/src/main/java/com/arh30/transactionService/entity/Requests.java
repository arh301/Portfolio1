package com.arh30.transactionService.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

// Requests Entity represents the Requests table and each instance represents a record in the table, with columns
// id, usernameD (debitor), usernameC (creditor), amount and currency.
// All fields are annotated @NotNull to ensure mandatory entry for creating a new record
// Auto-generated Getter and Setter methods and override methods are included
@Entity
@Table
public class Requests implements Serializable {

    // Id is an auto-generated field to provide a random unique id, all other fields are set via the contructor
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    String usernameD;

    @NotNull
    String usernameC;

    @NotNull
    double amount;

    @NotNull
    String currency;

    public Requests() {
    }

    // Contructor to create a new record/row in the Requests table, setting all fields excluding id
    public Requests(String usernameD, String usernameC, double amount, String currency) {
        this.usernameD = usernameD;
        this.usernameC = usernameC;
        this.amount = amount;
        this.currency = currency;
    }

    // Setter method for usernameD
    public void setUsernameD(String usernameD) {
        this.usernameD = usernameD;
    }

    // Getter method for usernameD
    public String getUsernameD() {
        return usernameD;
    }

    // Setter method for usernameC
    public void setUsernameC(String usernameC) {
        this.usernameC = usernameC;
    }

    // Getter method for usernameC
    public String getUsernameC() {
        return usernameC;
    }

    // Setter method for id
    public void setId(Long id) {
        this.id = id;
    }

    // Getter method for id
    public Long getId() {
        return id;
    }

    // Setter method for currency
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    // Getter method for currency
    public String getCurrency() {
        return currency;
    }

    // Setter method for amount
    public void setAmount(double amount) {
        this.amount = amount;
    }

    // Getter method for amount
    public double getAmount() {
        return amount;
    }

    // Override method for hashcode function
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.usernameC);
        hash = 97 * hash + Objects.hashCode(this.usernameD);
        return hash;
    }

    // Override method for equals function
    @Override
    public boolean equals(Object obj) {
        return true;
    }

    // Override method for toString function
    @Override
    public String toString() {
        return "Requests[ id=" + id + " ]";
    }

}
