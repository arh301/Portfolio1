package com.arh30.transactionService.ejb;

import com.arh30.transactionService.entity.SystemUser;
import com.arh30.transactionService.entity.Transactions;
import java.util.Collections;
import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

// Stateless EJB to provide transaction functionality
// Uses TransactionMangement container to safely commit transactions
// Accesses data through an Entity Manager to return user and transactions data
// Creates transactions and returns lists of users transactions
// Declarative security restricts EJB access to authorised users and admins 
@Stateless
@DeclareRoles({"users", "admins"})
@RolesAllowed({"users", "admins"})
@TransactionManagement(TransactionManagementType.CONTAINER)
public class TransService {

    @PersistenceContext(unitName = "WebappsPU")
    EntityManager em;

    // Method to create a new transaction by adding a record to the Transactions entity
    // Uses conversion method to convert payment amounts into the reciever's currency
    @TransactionAttribute(REQUIRED)
    public boolean write(String usernameD, String usernameC, double amount) {
        SystemUser sender = em.find(SystemUser.class, usernameD);
        SystemUser receiver = em.find(SystemUser.class, usernameC);
        double postCredit = sender.getBalance() - amount; // Check the user has enough credit for this transaction
        // If the payee is a valid user and the payer has enough credit, create transaction
        if (receiver != null && postCredit >= 0) {
            Transactions trans;
            sender.setBalance(postCredit); // Update payer balance
            String senderCur = sender.getCurrency();
            String receiverCur = receiver.getCurrency();
            double received = amount * conversion(senderCur, receiverCur); // Determine credit in payee's currency
            double receiverBalance = receiver.getBalance() + received;
            receiver.setBalance(receiverBalance); // Update payee balance

            trans = new Transactions(usernameD, usernameC, amount, senderCur);
            //Adds data records to entity Transactions, using the Entity Manager
            em.persist(trans);
            em.flush();
            return true;
        } else {

            return false;
        }
    }

    // Method to return the balance of the payer/sender using the Entity Manager
    public double getBalance(String usernameD) {
        SystemUser sender = em.find(SystemUser.class, usernameD);
        return sender.getBalance();
    }

    // Method to return the currency of a user using the Entity Manager
    public String getCurrency(String usernameD) {
        SystemUser user = em.find(SystemUser.class, usernameD);
        return user.getCurrency();
    }

    // Method to return currency conversion rate between a sending and receiving currency
    private double conversion(String senderCur, String receiverCur) {
        if ("GBP".equals(senderCur) && "EUR".equals(receiverCur)) {
            return 1.18;
        }
        if ("EUR".equals(senderCur) && "GBP".equals(receiverCur)) {
            return 0.85;
        }
        if ("GBP".equals(senderCur) && "USD".equals(receiverCur)) {
            return 1.29;
        }
        if ("USD".equals(senderCur) && "GBP".equals(receiverCur)) {
            return 0.78;
        }
        if ("GBP".equals(senderCur) && "USD".equals(receiverCur)) {
            return 1.29;
        }
        if ("USD".equals(senderCur) && "GBP".equals(receiverCur)) {
            return 0.78;
        }
        if ("USD".equals(senderCur) && "EUR".equals(receiverCur)) {
            return 0.92;
        }
        if ("EUR".equals(senderCur) && "USD".equals(receiverCur)) {
            return 1.09;
        }
        return 1;
    }

    // Setter method for EntityManager em
    public void setEm(EntityManager em) {
        this.em = em;
    }

    // Getter method for EntityManager em
    public EntityManager getEm() {
        return em;
    }

    // Method to return list of all the user's outgoing transactions
    // Uses the EntityManager and a named query defined in entity.Transactions.java 
    // to search Transactions entity for user specific data
    public synchronized List<Transactions> getTransList1(String usernameD) {

        Query query = em.createNamedQuery("findTrans");
        query.setParameter("usernameD", usernameD);
        List<Transactions> transactions = query.getResultList();
        Collections.reverse(transactions); //reorders the list so most recent appear at the top
        return transactions;
    }

    // Method to return list of all the user's incoming transactions
    // Uses the EntityManager and a named query defined in entity.Transactions.java 
    // to search Transactions entity for user specific data
    public synchronized List<Transactions> getTransList2(String usernameD) {

        Query query = em.createNamedQuery("findTrans2");
        query.setParameter("usernameD", usernameD);
        List<Transactions> transactions = query.getResultList();
        Collections.reverse(transactions); //reorders the list so most recent appear at the top
        return transactions;
    }

}
