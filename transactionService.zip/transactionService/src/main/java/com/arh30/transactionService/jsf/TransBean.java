package com.arh30.transactionService.jsf;

import com.arh30.transactionService.ejb.TransService;
import com.arh30.transactionService.entity.Transactions;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

// JSF bean to implement the transactions view (faces/users/trans.xhtml) functionality, 
// of making transaction records and returning lists of user's incoming/outgoing transactions
// Connects TransService EJB to access the persistence layer/Transaction entity and execute fucntions
// Auto-generated Getter and Setter methods and override methods are included
@Named
@RequestScoped
public class TransBean {

    @EJB
    TransService transSrv;
    String usernameD;
    String usernameC;
    int amount;
    String success;

    public TransBean() {
        // Set the requesting/creditor user for the request, using FacesContext methods
        usernameD = FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal().getName();
    }

    // Method to call respective EJB method to return a list of the user's outgoing transactions
    public List<Transactions> getTransList1() {
        return transSrv.getTransList1(usernameD);
    }

    // Method to call respective EJB method to return a list of the user's incoming transactions
    public List<Transactions> getTransList2() {
        return transSrv.getTransList2(usernameD);
    }

    // Method to call respective EJB method to make a transaction (record) to usernameC
    // Returns success/error message depending on the reuslt of the EJB method
    public void makeTransaction() {
        boolean made = transSrv.write(usernameD, usernameC, amount);
        if (made) {
            success = "Payment successfully completed";
        } else {
            success = "Error completing payment; either the username is incorrect or you have insufficient funds.";
        }
    }

    // Method to call respective EJB method to return user's currency for transaction
    public String getCurrency() {
        String result = transSrv.getCurrency(usernameD);
        return result;
    }

    // Method to return user balance
    public double getBalance() {
        double result = transSrv.getBalance(usernameD);
        return result;
    }

    // Getter method for success (message)
    public String getSuccess() {
        return success;
    }

    // Setter method for success (message)
    public void setSuccess(String success) {
        this.success = success;
    }

    // Getter method for transSrv
    public TransService getTransSrv() {
        return transSrv;
    }

    // Setter method for transSrv
    public void setTransSrv(TransService transSrv) {
        this.transSrv = transSrv;
    }

    // Getter method for usernameD
    public String getUsernameD() {
        return usernameD;
    }

    // Setter method for usernameD
    public void setUsernameD(String usernameD) {
        this.usernameD = usernameD;
    }

    // Getter method for usernameC
    public String getUsernameC() {
        return usernameC;
    }

    // Setter method for usernameC
    public void setUsernameC(String usernameC) {
        this.usernameC = usernameC;
    }

    // Getter method for amount
    public int getAmount() {
        return amount;
    }

    // Setter method for amount
    public void setAmount(int amount) {
        this.amount = amount;
    }
}
