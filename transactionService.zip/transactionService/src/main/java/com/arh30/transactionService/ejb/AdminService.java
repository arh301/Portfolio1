package com.arh30.transactionService.ejb;

import com.arh30.transactionService.entity.SystemUser;
import com.arh30.transactionService.entity.SystemUserGroup;
import com.arh30.transactionService.entity.Transactions;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

// Stateless EJB to provide admin functionality 
// Accesses data through an Entity Manager to return user and transactions data
// and create new admin users
// Declarative security restricts EJB access to authorised admins only
@Stateless
@DeclareRoles("admins")
@RolesAllowed("admins")
@TransactionManagement(TransactionManagementType.CONTAINER)
public class AdminService {

    @PersistenceContext(unitName = "WebappsPU")
    EntityManager em;

    // Method to return list of all transactions made by all users
    public synchronized List<Transactions> getTransList() {

        Query query = em.createQuery("SELECT t FROM Transactions t");
        List<Transactions> transactions = query.getResultList();
        Collections.reverse(transactions); //reorders the list so most recent transactions appear on top
        return transactions;
    }

    // Method to return list of all users (not admins) of the system
    public List<Transactions> getUserList() {

        Query query = em.createQuery("SELECT u FROM SystemUser u WHERE u.userGroup = 'users'");
        List<Transactions> transactions = query.getResultList();
        Collections.reverse(transactions); //reorders the list so most recently created users appear at the top
        return transactions;
    }

    // Method to create new admin user by adding data to the SystemUser and SystemUserGroup entities
    // Requires parameters username, userpassword and name, to set user data fields   
    @TransactionAttribute(REQUIRED)
    public String registerAdmin(String username, String userpassword, String name) {
                                                                                                               
        try {
            // Return error if username already exists
            SystemUser query = em.find(SystemUser.class, username);
            if(query != null){
                return "userExists";
            }
            SystemUser sys_user;
            SystemUserGroup sys_user_group;

            // Creates encrypted password to be saved to database
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String passwd = userpassword;
            md.update(passwd.getBytes("UTF-8"));
            byte[] digest = md.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String paswdToStoreInDB = bigInt.toString(16);

            sys_user = new SystemUser(username, paswdToStoreInDB, name, 1000, "GBP", "admins");
            sys_user_group = new SystemUserGroup(username, "admins");
            //Adds data records to entities SystemUser and SystemUserGroup, using the Entity Manager
            em.persist(sys_user);
            em.persist(sys_user_group);
            return "true";
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
            return "false";

        }
    }

}
