package com.arh30.transactionService.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

// SystemUser Entity represents the SystemUser table and each instance represents a record in the table, with columns
// username, userpassowrd, name, balance, currency and userGroup.
// All fields are annotated @NotNull to ensure mandatory entry for creating a new record
// Auto-generated Getter and Setter methods and override methods are included
@Entity
public class SystemUser implements Serializable {

    // Unique Id is set as user username to ensure each email address can only be associated to one account
    @Id
    @NotNull
    String username;

    @NotNull
    String userpassword;

    @NotNull
    String name;

    @NotNull
    double balance;

    @NotNull
    String currency;

    @NotNull
    String userGroup;

    public SystemUser() {
    }

    // Contructor to create a new record/row in the SystemUser table, setting all fields as passed parameters
    public SystemUser(String username, String userpassword, String name, double balance, String currency, String userGroup) {
        this.username = username;
        this.userpassword = userpassword;
        this.name = name;
        this.balance = balance;
        this.currency = currency;
        this.userGroup = userGroup;
    }

    // Getter method for userGroup
    public String getUserGroup() {
        return userGroup;
    }

    // Setter method for userGroup
    public void setUserGroup(String userGroup) {
        this.userGroup = userGroup;
    }

    // Getter method for username
    public String getUsername() {
        return username;
    }

    // Setter method for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter method for userpassword
    public String getUserpassword() {
        return userpassword;
    }

    // Setter method for userpassword
    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    // Getter method for name
    public String getName() {
        return name;
    }

    // Setter method for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for balance
    public double getBalance() {
        return balance;
    }

    // Setter method for balance
    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Getter method for currency
    public String getCurrency() {
        return currency;
    }

    // Setter method for currency
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    // Override method for hashCode function
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.username);
        hash = 97 * hash + Objects.hashCode(this.userpassword);
        hash = 97 * hash + Objects.hashCode(this.name);
        hash = 97 * hash + Objects.hashCode(this.balance);
        return hash;
    }

    // Override method for equals function
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SystemUser other = (SystemUser) obj;
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.userpassword, other.userpassword)) {
            return false;
        }
        if (!Objects.equals(this.balance, other.balance)) {
            return false;
        }
        return Objects.equals(this.name, other.name);
    }

}
